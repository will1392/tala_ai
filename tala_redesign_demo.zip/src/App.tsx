
import React, { useState } from "react";
import { ThemeProvider } from "./context/ThemeContext";
import Sidebar from "./components/layout/Sidebar";
import ChatView from "./components/chat/ChatView";
import Knowledge from "./components/knowledge/Knowledge";
import DemoFlow from "./components/demo/DemoFlow";

export default function App() {
  const [page, setPage] = useState<"chat" | "knowledge" | "demo">("chat");
  return (
    <ThemeProvider>
      <div className="mx-auto max-w-7xl flex">
        <Sidebar current={page} setCurrent={setPage} />
        <main className="flex-1 min-h-screen">
          {page === "chat" && <ChatView />}
          {page === "knowledge" && <Knowledge />}
          {page === "demo" && <DemoFlow />}
        </main>
      </div>
    </ThemeProvider>
  );
}
