
import React, { createContext, useContext, useEffect, useState } from "react";

type Theme = "light" | "dark";
type Ctx = { theme: Theme; toggle: () => void };

export const ThemeCtx = createContext<Ctx>({ theme: "dark", toggle: () => {} });
export const useTheme = () => useContext(ThemeCtx);

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<Theme>(() => {
    if (typeof window === "undefined") return "dark";
    return (localStorage.getItem("tala_theme") as Theme) || 
           (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
  });

  useEffect(() => {
    const root = document.documentElement;
    if (theme === "dark") root.classList.add("dark"); else root.classList.remove("dark");
    localStorage.setItem("tala_theme", theme);
  }, [theme]);

  return (
    <ThemeCtx.Provider value={{ theme, toggle: () => setTheme(t => (t === "dark" ? "light" : "dark")) }}>
      <div className="min-h-screen bg-[var(--bg)] text-[var(--fg)] transition-colors duration-300">
        <style>{`
          :root { --bg: #f7f9fc; --panel:#ffffff; --muted:#4b5563; --fg:#0f172a; --primary:#0EC5C5; --ring:#0EC5C580; --border:#E5E7EB; }
          .dark { --bg:#0b1220; --panel:#0f172a; --muted:#94a3b8; --fg:#e2e8f0; --primary:#0EC5C5; --ring:#0EC5C580; --border:#1f2937; }
          *{outline-color:var(--ring)}
        `}</style>
        {children}
      </div>
    </ThemeCtx.Provider>
  );
}
