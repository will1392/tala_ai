
import React, { useMemo, useState } from "react";
import Topbar from "../layout/Topbar";
import { Folder, Search, FileText, BookOpen, CheckCircle2, Trash2 } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";

const MOCK_FOLDERS = [
  { id: "reports", name: "Reports" },
  { id: "marketing", name: "Marketing" },
  { id: "finance", name: "Finance" },
  { id: "ideas", name: "Ideas" },
];
const MOCK_DOCS: { id: string; title: string; folder: string; type: string; updated: string }[] = [
  { id: "1", title: "Q1 Financials.xlsx", folder: "finance", type: "Spreadsheet", updated: "2h ago" },
  { id: "2", title: "Marketing Plan 2025.docx", folder: "marketing", type: "Document", updated: "today" },
  { id: "3", title: "Iberia Beaches Guide.md", folder: "reports", type: "Markdown", updated: "yesterday" },
  { id: "4", title: "AI Presentation.pptx", folder: "ideas", type: "Presentation", updated: "4d ago" },
];

export default function Knowledge() {
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<string | null>(null);
  const [active, setActive] = useState(MOCK_DOCS[2]);

  const results = useMemo(() => {
    return MOCK_DOCS.filter((d) => (!filter || d.folder === filter) && d.title.toLowerCase().includes(query.toLowerCase()));
  }, [query, filter]);

  return (
    <div className="h-full flex flex-col">
      <Topbar title="Knowledge Workspace" onNew={() => alert("Upload modal (mock)")} />
      <div className="mx-auto w-full max-w-7xl px-4 py-4 grid grid-cols-12 gap-4">
        <section className="col-span-12 md:col-span-3 rounded-2xl border border-[var(--border)] bg-[var(--panel)] p-3">
          <div className="text-xs uppercase tracking-wide text-[var(--muted)] mb-2">Folders</div>
          <div className="space-y-1">
            <button onClick={() => setFilter(null)} className={`w-full text-left px-3 py-2 rounded-lg ${filter === null ? "bg-[var(--primary)]/10" : "hover:bg-[var(--primary)]/5"}`}>
              All
            </button>
            {MOCK_FOLDERS.map((f) => (
              <button key={f.id} onClick={() => setFilter(f.id)} className={`w-full text-left px-3 py-2 rounded-lg ${filter === f.id ? "bg-[var(--primary)]/10" : "hover:bg-[var(--primary)]/5"}`}>
                <Folder size={14} className="inline mr-2" />
                {f.name}
              </button>
            ))}
          </div>
        </section>

        <section className="col-span-12 md:col-span-5 rounded-2xl border border-[var(--border)] bg-[var(--panel)] p-3">
          <div className="flex items_center gap-2 rounded-xl border border-[var(--border)] bg-[var(--panel)] px-3 py-2 focus-within:ring-2 focus-within:ring-[var(--ring)]">
            <Search size={16} className="text-[var(--muted)]" />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search knowledge…" className="bg-transparent outline-none text-sm w-full" />
          </div>
          <div className="mt-3 divide-y divide-[var(--border)]">
            <AnimatePresence mode="popLayout">
              {results.map((d) => (
                <motion.button
                  key={d.id}
                  onClick={() => setActive(d)}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -6 }}
                  className={`w-full text-left px-2 py-3 flex items-center gap-3 hover:bg-[var(--primary)]/5 rounded-lg ${active?.id === d.id ? "ring-1 ring-[var(--ring)]" : ""}`}
                >
                  <FileText size={16} />
                  <div>
                    <div className="text-sm font-medium">{d.title}</div>
                    <div className="text-xs text-[var(--muted)]">
                      {d.type} • {d.updated}
                    </div>
                  </div>
                </motion.button>
              ))}
            </AnimatePresence>
          </div>
        </section>

        <section className="col-span-12 md:col-span-4 rounded-2xl border border-[var(--border)] bg-[var(--panel)] p-4">
          <div className="text-sm font-semibold flex items-center gap-2">
            <BookOpen size={16} /> Preview
          </div>
          {active ? (
            <div className="mt-3 space-y-3">
              <div className="text-lg font-semibold">{active.title}</div>
              <div className="text-xs text-[var(--muted)]">
                {active.type} • Updated {active.updated}
              </div>
              <div className="rounded-xl border border-[var(--border)] p-3 text-sm leading-relaxed bg-[var(--bg)]/40">
                <p className="mb-2">This is a mock preview to illustrate layout: excerpts, detected entities, and quick actions could appear here.</p>
                <ul className="list-disc ml-4">
                  <li>Auto‑summary snippet</li>
                  <li>Top entities & tags</li>
                  <li>Source links and confidence</li>
                </ul>
              </div>
              <div className="flex items-center gap-2">
                <button className="rounded-xl bg-[var(--primary)]/90 text-black px-3 py-2 text-sm font-medium">
                  <CheckCircle2 size={16} className="inline mr-1" /> Use in Chat
                </button>
                <button className="rounded-xl border border-[var(--border)] px-3 py-2 text-sm hover:border-[var(--primary)]/60">
                  <Trash2 size={16} className="inline mr-1" /> Remove
                </button>
              </div>
            </div>
          ) : (
            <div className="text-sm text-[var(--muted)] mt-2">Select a document to preview.</div>
          )}
        </section>
      </div>
    </div>
  );
}
