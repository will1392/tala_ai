
import React from "react";
import { Bot, MessageCircle, BookOpen, PlayCircle } from "lucide-react";

export default function Sidebar({ current, setCurrent }: { current: string; setCurrent: (v: string) => void }) {
  const items = [
    { key: "chat", label: "Chat", icon: MessageCircle },
    { key: "knowledge", label: "Knowledge", icon: BookOpen },
    { key: "demo", label: "Demo Flow", icon: PlayCircle },
  ];
  return (
    <aside className="h-screen sticky top-0 border-r border-[var(--border)] hidden md:flex md:flex-col w-60 bg-[var(--panel)]">
      <div className="px-4 py-4 flex items-center gap-2 border-b border-[var(--border)]">
        <Bot className="text-[var(--primary)]" />
        <div className="font-semibold">Tala</div>
      </div>
      <nav className="p-2 space-y-1">
        {items.map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            onClick={() => setCurrent(key)}
            className={`w-full text-left flex items-center gap-3 px-3 py-2 rounded-xl transition-colors focus:ring-2 focus:ring-[var(--ring)] ${
              current === key ? "bg-[var(--primary)]/10 border border-[var(--primary)]/30" : "hover:bg-[var(--primary)]/5"
            }`}
          >
            <Icon size={18} />
            <span className="text-sm">{label}</span>
          </button>
        ))}
      </nav>
      <div className="mt-auto p-3 text-xs text-[var(--muted)]">UI demo • dummy data • no backend</div>
    </aside>
  );
}
