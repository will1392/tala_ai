
# Tala UI Redesign – Drop‑in Demo

This folder contains a **self‑contained React/Tailwind demo** that reproduces the light/dark toggle, animated chat with staged progress, Knowledge workspace and a Demo Flow stream. It uses **framer‑motion** and **lucide‑react**.

## Install (in your existing repo)

```bash
# deps
npm i framer-motion lucide-react

# tailwind (if your project doesn't have it)
npm i -D tailwindcss postcss autoprefixer
npx tailwindcss init -p

# tailwind.config.js
# ensure:  darkMode: 'class'  and content globs include ./src/**
```

## Add files

Copy the `src/` files from this folder into your repo (preserving paths). Wrap your root in `<ThemeProvider>` and mount `<App />` or integrate the components into your layout.

## Theme tokens (exact)
Defined inside `ThemeProvider` as CSS variables:

```
:root { --bg:#f7f9fc; --panel:#fff; --muted:#4b5563; --fg:#0f172a; --primary:#0EC5C5; --ring:#0EC5C580; --border:#E5E7EB; }
.dark { --bg:#0b1220; --panel:#0f172a; --muted:#94a3b8; --fg:#e2e8f0; --primary:#0EC5C5; --ring:#0EC5C580; --border:#1f2937; }
```

## QA checklist
- Theme persists via `localStorage('tala_theme')` and toggles `documentElement.classList`.
- Chat bubbles spring in with `{stiffness:300,damping:24}`; stage order: received → uploading → processing → answering → complete.
- Demo Flow shows 6 events at 300/900/1500/2100/2600/3000ms.
- Focus rings visible; Enter sends message.

## Suggested PR title/description
**Title:** UI: Add dark/light theme, animated chat, and demo flow scaffold  
**Body:** Introduces ThemeProvider + tokens, chat animation + StageBar, Knowledge workspace panels, and a status streaming demo. Feature‑flag friendly; no backend required.
